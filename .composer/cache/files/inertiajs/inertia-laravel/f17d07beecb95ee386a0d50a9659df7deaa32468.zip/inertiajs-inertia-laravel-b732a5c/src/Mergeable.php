<?php

namespace Inertia;

interface Mergeable
{
    public function merge();

    public function shouldMerge();
}
